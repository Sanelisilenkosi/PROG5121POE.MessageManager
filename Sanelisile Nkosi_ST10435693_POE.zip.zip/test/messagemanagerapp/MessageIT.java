package messagemanagerapp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import java.util.Arrays;

class MessageManagerTest {
    
    @Test
    void testSentMessagesArrayPopulated() {
        MessageManager manager = new MessageManager();
        manager.populateTestData();
        
        ArrayList<Message> sentMessages = manager.getSentMessages();
        assertEquals(2, sentMessages.size());
        
        boolean foundMessage1 = false;
        boolean foundMessage4 = false;
        
        for (Message msg : sentMessages) {
            if (msg.getMessage().equals("Did you get the cake?")) {
                foundMessage1 = true;
            }
            if (msg.getMessage().equals("It is dinner time!")) {
                foundMessage4 = true;
            }
        }
        
        assertTrue(foundMessage1, "Should contain 'Did you get the cake?'");
        assertTrue(foundMessage4, "Should contain 'It is dinner time!'");
    }
    
    @Test
    void testDisplayLongestMessage() {
        MessageManager manager = new MessageManager();
        manager.populateTestData();
        
        ArrayList<Message> sentMessages = manager.getSentMessages();
        Message longest = null;
        
        for (Message msg : sentMessages) {
            if (longest == null || msg.getMessage().length() > longest.getMessage().length()) {
                longest = msg;
            }
        }
        
        assertNotNull(longest, "Should find a longest message");
        assertEquals("Where are you? You are late! I have asked you to be on time.", 
                    longest.getMessage(), "Should identify the correct longest message");
    }
    
    @Test
    void testSearchByMessageID() {
        MessageManager manager = new MessageManager();
        manager.populateTestData();
        
        String searchID = "MSG004";
        ArrayList<Message> allMessages = new ArrayList<>();
        allMessages.addAll(manager.getSentMessages());
        allMessages.addAll(manager.getStoredMessages());
        allMessages.addAll(manager.getDisregardedMessages());
        
        boolean found = false;
        for (Message msg : allMessages) {
            if (msg.getMessageID().equals(searchID) && msg.getMessage().equals("It is dinner time!")) {
                found = true;
                break;
            }
        }
        
        assertTrue(found, "Should find message with ID MSG004 containing 'It is dinner time!'");
    }
    
    @Test
    void testSearchMessagesByRecipient() {
        MessageManager manager = new MessageManager();
        manager.populateTestData();
        
        String recipient = "+27838884567";
        ArrayList<Message> allMessages = new ArrayList<>();
        allMessages.addAll(manager.getSentMessages());
        allMessages.addAll(manager.getStoredMessages());
        allMessages.addAll(manager.getDisregardedMessages());
        
        int count = 0;
        for (Message msg : allMessages) {
            if (msg.getRecipient().equals(recipient)) {
                count++;
            }
        }
        
        assertEquals(2, count, "Should find 2 messages for recipient +27838884567");
    }
    
    @Test
    void testDeleteMessageByHash() {
        MessageManager manager = new MessageManager();
        manager.populateTestData();
        
        String hashToDelete = manager.getFirstSentMessageHash();
        assertNotNull(hashToDelete, "Should have a message hash to delete");
        
        int initialSize = manager.getSentMessages().size();
        boolean deleted = manager.deleteMessageByHash(hashToDelete);
        
        assertTrue(deleted, "Message should be successfully deleted");
        assertEquals(initialSize - 1, manager.getSentMessages().size(), 
                    "Sent messages array should decrease by 1 after deletion");
    }
    
    @Test
    void testAllArraysPopulated() {
        MessageManager manager = new MessageManager();
        manager.populateTestData();
        
        assertFalse(manager.getSentMessages().isEmpty(), "Sent messages array should be populated");
        assertFalse(manager.getStoredMessages().isEmpty(), "Stored messages array should be populated");
        assertFalse(manager.getDisregardedMessages().isEmpty(), "Disregarded messages array should be populated");
        assertFalse(manager.getMessageHashes().isEmpty(), "Message hashes array should be populated");
        assertFalse(manager.getMessageIDs().isEmpty(), "Message IDs array should be populated");
    }
}
