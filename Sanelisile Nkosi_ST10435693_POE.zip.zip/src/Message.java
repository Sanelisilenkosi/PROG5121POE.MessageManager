package messagemanagerapp;

import java.util.Objects;

public class Message {
    private String messageID;
    private String recipient;
    private String message;
    private String flag;
    private String messageHash;
    
    public Message(String messageID, String recipient, String message, String flag) {
        this.messageID = messageID;
        this.recipient = recipient;
        this.message = message;
        this.flag = flag;
        this.messageHash = generateHash(messageID + recipient + message);
    }
    
    private String generateHash(String input) {
        return Integer.toHexString(Objects.hash(input));
    }
    
    public String getMessageID() { return messageID; }
    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }
    public String getFlag() { return flag; }
    public String getMessageHash() { return messageHash; }
    
    public void setFlag(String flag) { this.flag = flag; }
    
    @Override
    public String toString() {
        return String.format("MessageHash: %s | Recipient: %s | Message: %s", 
                           messageHash, recipient, message);
    }
}