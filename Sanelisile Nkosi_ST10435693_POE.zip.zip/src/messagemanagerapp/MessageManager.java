package messagemanagerapp;

import java.util.*;

public class MessageManager {
    private ArrayList<Message> sentMessages = new ArrayList<>();
    private ArrayList<Message> disregardedMessages = new ArrayList<>();
    private ArrayList<Message> storedMessages = new ArrayList<>();
    private ArrayList<String> messageHashes = new ArrayList<>();
    private ArrayList<String> messageIDs = new ArrayList<>();
    
    public void populateTestData() {
        addMessage("MSG001", "+27834557896", "Did you get the cake?", "Sent");
        addMessage("MSG002", "+27838884567", "Where are you? You are late! I have asked you to be on time.", "Stored");
        addMessage("MSG003", "+27834484567", "Yohoooo, I am at your gate.", "Disregard");
        addMessage("MSG004", "0838884567", "It is dinner time!", "Sent");
        addMessage("MSG005", "+27838884567", "Ok, I am leaving without you.", "Stored");
    }
    
    private void addMessage(String messageID, String recipient, String message, String flag) {
        Message newMessage = new Message(messageID, recipient, message, flag);
        
        switch(flag.toLowerCase()) {
            case "sent": sentMessages.add(newMessage); break;
            case "disregard": disregardedMessages.add(newMessage); break;
            case "stored": storedMessages.add(newMessage); break;
        }
        
        messageHashes.add(newMessage.getMessageHash());
        messageIDs.add(newMessage.getMessageID());
    }
    
    public void displaySentMessagesSendersRecipients() {
        System.out.println("=== Sent Messages Senders and Recipients ===");
        for (Message msg : sentMessages) {
            System.out.println("Sender: System | Recipient: " + msg.getRecipient());
        }
        System.out.println();
    }
    
    public void displayLongestSentMessage() {
        Message longestMessage = null;
        for (Message msg : sentMessages) {
            if (longestMessage == null || msg.getMessage().length() > longestMessage.getMessage().length()) {
                longestMessage = msg;
            }
        }
        
        if (longestMessage != null) {
            System.out.println("=== Longest Sent Message ===");
            System.out.println("Recipient: " + longestMessage.getRecipient());
            System.out.println("Message: " + longestMessage.getMessage());
            System.out.println("Length: " + longestMessage.getMessage().length() + " characters");
        }
        System.out.println();
    }
    
    public void searchByMessageID(String messageID) {
        System.out.println("=== Search Results for Message ID: " + messageID + " ===");
        for (Message msg : getAllMessages()) {
            if (msg.getMessageID().equals(messageID)) {
                System.out.println("Recipient: " + msg.getRecipient());
                System.out.println("Message: " + msg.getMessage());
                System.out.println();
                return;
            }
        }
        System.out.println("Message ID not found.");
        System.out.println();
    }
    
    public void searchMessagesByRecipient(String recipient) {
        System.out.println("=== Messages for Recipient: " + recipient + " ===");
        boolean found = false;
        for (Message msg : getAllMessages()) {
            if (msg.getRecipient().equals(recipient)) {
                System.out.println("Message: " + msg.getMessage() + " | Flag: " + msg.getFlag());
                found = true;
            }
        }
        if (!found) System.out.println("No messages found for this recipient.");
        System.out.println();
    }
    
    public boolean deleteMessageByHash(String messageHash) {
        for (ArrayList<Message> messageList : Arrays.asList(sentMessages, disregardedMessages, storedMessages)) {
            Iterator<Message> iterator = messageList.iterator();
            while (iterator.hasNext()) {
                Message msg = iterator.next();
                if (msg.getMessageHash().equals(messageHash)) {
                    iterator.remove();
                    messageHashes.remove(messageHash);
                    messageIDs.remove(msg.getMessageID());
                    System.out.println("Message successfully deleted: " + msg.getMessage());
                    System.out.println();
                    return true;
                }
            }
        }
        System.out.println("Message hash not found.");
        System.out.println();
        return false;
    }
    
    public void displaySentMessagesReport() {
        System.out.println("=== Sent Messages Report ===");
        System.out.printf("%-20s %-15s %s%n", "Message Hash", "Recipient", "Message");
        System.out.println("------------------------------------------------------------");
        for (Message msg : sentMessages) {
            System.out.printf("%-20s %-15s %s%n", msg.getMessageHash(), msg.getRecipient(), msg.getMessage());
        }
        System.out.println();
    }
    
    private ArrayList<Message> getAllMessages() {
        ArrayList<Message> allMessages = new ArrayList<>();
        allMessages.addAll(sentMessages);
        allMessages.addAll(disregardedMessages);
        allMessages.addAll(storedMessages);
        return allMessages;
    }
    
    public ArrayList<Message> getSentMessages() { return sentMessages; }
    public ArrayList<Message> getDisregardedMessages() { return disregardedMessages; }
    public ArrayList<Message> getStoredMessages() { return storedMessages; }
    public ArrayList<String> getMessageHashes() { return messageHashes; }
    public ArrayList<String> getMessageIDs() { return messageIDs; }
    
    public String getFirstSentMessageHash() {
        return sentMessages.isEmpty() ? null : sentMessages.get(0).getMessageHash();
    }
}