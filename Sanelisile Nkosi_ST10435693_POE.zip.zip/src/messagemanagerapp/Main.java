package messagemanagerapp;

public class Main {
    public static void main(String[] args) {
        System.out.println("=================================================");
        System.out.println("MESSAGE MANAGER APPLICATION");
        System.out.println("Student: Sanelisile Nkosi");
        System.out.println("Student Number: ST10435693");
        System.out.println("Course: Bachelor of IT in Business Systems");
        System.out.println("Module: PROG5121 - Programming 1A");
        System.out.println("=================================================\n");
        
        MessageManager manager = new MessageManager();
        manager.populateTestData();
        System.out.println("✅ Test data loaded successfully!\n");
        
        demonstrateAllFeatures(manager);
        
        System.out.println("=================================================");
        System.out.println("APPLICATION COMPLETED SUCCESSFULLY");
        System.out.println("All features demonstrated as per requirements");
        System.out.println("=================================================");
    }
    
    private static void demonstrateAllFeatures(MessageManager manager) {
        System.out.println("🎯 DEMONSTRATING ALL REQUIRED FEATURES\n");
        
        System.out.println("a) DISPLAY SENDER AND RECIPIENT OF ALL SENT MESSAGES:");
        manager.displaySentMessagesSendersRecipients();
        
        System.out.println("b) DISPLAY THE LONGEST SENT MESSAGE:");
        manager.displayLongestSentMessage();
        
        System.out.println("c) SEARCH FOR MESSAGE BY ID:");
        manager.searchByMessageID("MSG004");
        
        System.out.println("d) SEARCH FOR MESSAGES BY RECIPIENT:");
        manager.searchMessagesByRecipient("+27838884567");
        
        System.out.println("e) DISPLAY SENT MESSAGES REPORT (BEFORE DELETION):");
        manager.displaySentMessagesReport();
        
        System.out.println("f) DELETE MESSAGE USING MESSAGE HASH:");
        if (!manager.getSentMessages().isEmpty()) {
            String hashToDelete = manager.getSentMessages().get(0).getMessageHash();
            manager.deleteMessageByHash(hashToDelete);
        }
        
        System.out.println("g) DISPLAY SENT MESSAGES REPORT (AFTER DELETION):");
        manager.displaySentMessagesReport();
    }
}